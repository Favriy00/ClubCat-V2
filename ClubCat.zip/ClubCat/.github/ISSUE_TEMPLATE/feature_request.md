---
name: Idea o mejora
about: Propón una función nueva para ClubCat
labels: enhancement
---

**¿Qué te gustaría que hiciera ClubCat?**

**¿Por qué sería útil?**

**Referencias de diseño (opcional)**
