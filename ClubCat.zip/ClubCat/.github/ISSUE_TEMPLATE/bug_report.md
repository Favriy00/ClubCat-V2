---
name: Reporte de bug
about: Algo no funciona como debería
labels: bug
---

**¿Qué pasó?**

**Pasos para reproducirlo**
1.
2.

**¿Qué esperabas que pasara?**

**Dispositivo y versión de Android**

**Capturas o logs (opcional)**
