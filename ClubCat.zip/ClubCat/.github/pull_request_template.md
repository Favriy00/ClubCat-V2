## Qué cambia

## Cómo probarlo

## Checklist
- [ ] Compila (`gradle assembleDebug`)
- [ ] Probado en dispositivo o emulador
- [ ] Capturas añadidas si cambia la UI
